class Customer < ApplicationRecord
    has_one :adreess

end
